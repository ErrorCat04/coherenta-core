# Document 2 — Spécification du Noyau (v0.3)

## Postulat

Toute action A modifie un ensemble de systèmes S à travers le temps.

Formellement :
A : S(t) → S(t + Δt)

L’impact I est défini par :
I = (ΔSt, ΔAu, ΔCa)

ΔSt = variation de stabilité
ΔAu = variation d’autonomie
ΔCa = variation de capacité adaptative

Le Noyau ne juge pas moralement.
Il rend visibles les variations structurelles.

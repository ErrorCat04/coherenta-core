# Coherenta v0.1.0-rc

Statut : Release Candidate (non signée)
Phase : Test en cercle restreint

Objectif :
- Audit de cohérence final
- Test réel du module CBA
- Validation gouvernance minimale
- Préparation signature officielle

Cette version est complète structurellement.

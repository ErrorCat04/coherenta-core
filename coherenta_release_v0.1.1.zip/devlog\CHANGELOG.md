# CHANGELOG

## v0.1.1-rc
l'ia avais generer les dossier précédent grace a mes recherche et aujourd'hui l'on crée la version 0.1.1 correspondant a la 1er realse (implémentaion cas réel d'usage module CBA assisté IA (Fl0bull07, ErrorCat04, ChatGPT))

# Document 3 — Les 4 Domaines Fondamentaux

## Temps
Transformation, séquence, cycle, durée, anticipation.

## Espace
Position, distance, réseau, centre, périphérie.

## Matière
Structures concrètes, ressources, contraintes physiques.

## Langage (Méta-Domaine)
Cadre symbolique structurant la perception des trois autres domaines.

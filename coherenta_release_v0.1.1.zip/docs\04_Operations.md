# Document 4 — Opérations Structurelles

Une opération est une transformation appliquée à un système.

Op : S → S’

Les opérations émergent de :
Domaine × Fonction × Intensité × Échelle

Exemples :
- Stabiliser
- Transformer
- Relier
- Fragmenter
- Redistribuer
- Synchroniser

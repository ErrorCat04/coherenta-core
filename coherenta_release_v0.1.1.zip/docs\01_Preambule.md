# Document 1 — Préambule (v0.1)

Les sociétés humaines évoluent dans des environnements de complexité croissante.
Les décisions individuelles et collectives produisent des effets systémiques souvent invisibles.

Coherenta est une architecture ouverte visant à rendre visibles les impacts structurels des actions
afin d’augmenter la capacité collective à gérer la complexité sans imposer de direction normative.

Il n’intervient pas sur le réel.
Il structure la lecture du réel.
L’adoption est volontaire.

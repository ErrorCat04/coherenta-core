# Gouvernance — v0.1

- Participation ouverte
- Comité rotatif tiré au sort
- Analyse automatique d’alerte (non décisionnelle)
- Période publique d’objection
- Archivage immuable des versions validées

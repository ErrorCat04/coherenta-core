# Document 5 — Module CBA Multi-Couches

## Couche 1 — CBA
Mesure primaire : ΔSt, ΔAu, ΔCa

## Couche 2 — Cohérence Systémique
Analyse des tensions internes entre ΔSt, ΔAu, ΔCa

## Couche 3 — Méta-Cohérence
Comparaison entre couche 1 et couche 2 pour détecter incohérences structurelles.

Principe :
Une couche ne doit augmenter la complexité que si elle augmente la clarté.
